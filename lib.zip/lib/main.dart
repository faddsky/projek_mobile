import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'routes/app_pages.dart';
import 'bindings/initial_binding.dart';
import 'services/database_service.dart';

void main() async {
  // Menyiapkan plugin sistem sebelum aplikasi dijalankan
  WidgetsFlutterBinding.ensureInitialized();

  // Load file .env agar API Key Gemini bisa dibaca
  try {
    await dotenv.load(fileName: ".env");
    print("Environment variables loaded successfully! ✅");
  } catch (e) {
    print("Error loading .env file: $e ❌");
  }

  // Inisialisasi Database
  await Get.putAsync(() => DatabaseService().init());

  runApp(const EcoStepApp());
}

class EcoStepApp extends StatelessWidget {
  const EcoStepApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'EcoStep',
      debugShowCheckedModeBanner: false,
      
      // PERBAIKAN TEMA: Menggunakan cara yang benar untuk Material 3
      theme: ThemeData(
        useMaterial3: true,
        // Hapus primarySwatch jika menggunakan colorScheme agar tidak konflik
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6B8E23), // Olive Green
          primary: const Color(0xFF6B8E23),
          secondary: const Color(0xFF8DAA91),
          surface: const Color(0xFFFBFDFB),
        ),
        
        // Atur background secara global
        scaffoldBackgroundColor: const Color(0xFFF8FAF8),
        
        // Tema AppBar global agar serasi di semua halaman
        appBarTheme: const AppBarTheme(
          elevation: 0,
          centerTitle: true,
          backgroundColor: Colors.transparent,
          surfaceTintColor: Colors.transparent,
          titleTextStyle: TextStyle(
            color: Color(0xFF2E3D10),
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      // Navigasi
      initialRoute: AppRoutes.INITIAL,
      getPages: AppRoutes.routes,
      initialBinding: InitialBinding(),
    );
  }
}